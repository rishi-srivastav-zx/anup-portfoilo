# Origin Section Integration Guide

## 1. Install Required Dependencies
```bash
npm install gsap lucide-react
```

## 2. Add Google Fonts
Add the contents of `font-imports.html` into your `index.html` `<head>` or Next.js `app/layout.tsx`.

## 3. Include CSS Utilities
Import `origin-styles.css` in your root stylesheet or `globals.css`:
```css
@import "./origin-styles.css";
```

## 4. Mount Component
```tsx
import { OriginSection } from './OriginSection';

export default function Page() {
  return (
    <main className="bg-[#010204]">
      <OriginSection />
    </main>
  );
}
```

*Note for Next.js App Router:* Ensure `'use client';` is at the very top of `OriginSection.tsx`.
